//
//  Boek.m
//  TableDemo
//
//  Created by Raymond Van Dongelen on 11/5/12.
//  Copyright (c) 2012 Raymond Van Dongelen. All rights reserved.
//

#import "Boek.h"


@implementation Boek

@dynamic auteur;
@dynamic titel;

@end
