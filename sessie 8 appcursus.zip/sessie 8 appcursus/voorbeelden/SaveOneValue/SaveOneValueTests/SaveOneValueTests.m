//
//  SaveOneValueTests.m
//  SaveOneValueTests
//
//  Created by Raymond Van Dongelen on 11/4/12.
//  Copyright (c) 2012 Raymond Van Dongelen. All rights reserved.
//

#import "SaveOneValueTests.h"

@implementation SaveOneValueTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in SaveOneValueTests");
}

@end
