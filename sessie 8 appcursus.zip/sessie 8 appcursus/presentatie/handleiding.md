# Sessie 8

## Doel
Verschillende manieren van dataopslag

## Lezen en doen


# Inhoud
Dataopslag verschillende manieren tonen:
- Starten met UserDefaults
- Starten met plist
- CoreData aanraken, maar misschien niet laten zien


# Voorbeeld 1
Userdefaults laten zien in het kleine voorbeeld

# Voorbeeld 2
NSUserDefaults in de app

#Voorbeeld 3
Gebruik van plists


# Voorbeeld 4
Coredata voorbeeld